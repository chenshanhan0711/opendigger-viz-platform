from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager

# 全局扩展对象，延迟绑定到app
db = SQLAlchemy()
jwt = JWTManager()