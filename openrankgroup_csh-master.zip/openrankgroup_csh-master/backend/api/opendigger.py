from flask import Blueprint, jsonify
import os
import requests
import pandas as pd
from pathlib import Path
from datetime import datetime

# 基础蓝图：所有 API 路由的根前缀为 /api
api_bp = Blueprint("api", __name__, url_prefix="/api")

# ========== 自定义异常类：统一 API 错误返回格式 ==========
class ApiException(Exception):
    """简单的 API 异常类，包含状态码和错误详情"""
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(detail)

# 蓝图级错误处理器：将 ApiException 转为 JSON 响应
@api_bp.errorhandler(ApiException)
def handle_api_exception(e: ApiException):
    return jsonify({"detail": e.detail}), e.status_code

# ========== 公共工具函数：抓取 & 缓存 OpenDigger 数据 ==========
def fetch_and_save_opendigger_data(api_url: str, cache_key: str) -> dict:
    """
    从 OpenDigger 官方接口抓取数据，本地 CSV 缓存（避免重复请求）
    :param api_url: OpenDigger 官方数据接口 URL
    :param cache_key: 缓存文件唯一标识（如 "github_vuejs_vue_activity"）
    :return: 格式化后的指标数据（{"data": [["2023-01", 120.5], ...]}）
    """
    # 缓存目录：和 main.py 中一致（backend/data/）
    base_dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))  # backend/ 目录
    data_dir = Path(base_dir) / "data"
    data_dir.mkdir(exist_ok=True)  # 确保缓存目录存在
    cache_file = data_dir / f"{cache_key}.csv"

    # 1. 优先读取本地缓存
    if cache_file.exists():
        try:
            df = pd.read_csv(cache_file, encoding="utf-8-sig")
            # 转为前端需要的二维数组格式 [["月份", 数值], ...]
            result_data = df[["month", "count"]].values.tolist()
            return {"data": result_data}
        except Exception as e:
            raise ApiException(500, f"读取缓存失败：{str(e)}")

    # 2. 缓存不存在，请求 OpenDigger 官方接口
    try:
        # 同步请求（Flask 默认同步模式）
        response = requests.get(api_url, timeout=30, verify=False)
        response.raise_for_status()  # 触发 HTTP 错误（如 404、500）
        raw_data = response.json()

        # 3. 格式化数据：仅保留月度数据（YYYY-MM 格式）
        formatted_data = []
        for date_str, value in raw_data.items():
            # 校验日期格式为 YYYY-MM（长度7，含1个横杠）
            if len(date_str) == 7 and date_str.count("-") == 1:
                try:
                    # 验证日期有效性，过滤非法日期
                    datetime.strptime(date_str, "%Y-%m")
                    # 数值保留1位小数
                    formatted_data.append({
                        "month": date_str,
                        "count": round(float(value), 1)
                    })
                except ValueError:
                    continue  # 跳过非法日期格式

        if not formatted_data:
            raise ApiException(404, "无有效月度指标数据")

        # 4. 保存到 CSV 缓存
        pd.DataFrame(formatted_data).to_csv(
            cache_file, index=False, encoding="utf-8-sig"
        )

        # 5. 转为前端需要的二维数组
        result_data = [[item["month"], item["count"]] for item in formatted_data]
        return {"data": result_data}

    except requests.exceptions.HTTPError as e:
        if response.status_code == 404:
            raise ApiException(404, "OpenDigger 未导出该指标数据")
        else:
            raise ApiException(500, f"请求 OpenDigger 失败：{str(e)}")
    except Exception as e:
        raise ApiException(500, f"数据处理失败：{str(e)}")