from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
import json
from extensions import db
from models import Favorite
from .opendigger import ApiException

# 收藏蓝图（增删查）
favorites_bp = Blueprint("favorites", __name__, url_prefix="/api/favorites")

# 异常处理复用
@favorites_bp.errorhandler(ApiException)
def handle_exc(e: ApiException):
    return jsonify({"detail": e.detail}), e.status_code

# 辅助函数：生成对比类收藏的uniq_key
def build_compare_key(repos: list[str]) -> str:
    rs = sorted([r.strip() for r in repos if r and r.strip()])
    return "compare:" + ",".join(rs)

# 辅助函数：生成单项目指标收藏的uniq_key
def build_single_key(full_name: str, metric: str, platform: str) -> str:
    return f"single:{platform}:{full_name}:{metric}"

@favorites_bp.route("", methods=["GET"])
@jwt_required()
def list_favorites():
    """查询当前用户的所有收藏"""
    uid = int(get_jwt_identity())
    # 按创建时间倒序返回
    items = Favorite.query.filter_by(user_id=uid).order_by(Favorite.id.desc()).all()
    return jsonify({"favorites": [x.to_dict() for x in items]}), 200

@favorites_bp.route("", methods=["POST"])
@jwt_required()
def add_favorite():
    """新增收藏（支持single/plan两种类型）"""
    uid = int(get_jwt_identity())
    data = request.get_json(silent=True) or {}
    kind = (data.get("kind") or "single").strip()

    # 1. 收藏类型：plan（方案/榜单/对比结果）
    if kind == "plan":
        payload = data.get("payload") or {}
        uniq_key = (data.get("uniq_key") or "").strip()
        if not uniq_key:
            raise ApiException(400, "plan 收藏必须提供 uniq_key")
        
        fav = Favorite(
            user_id=uid,
            kind="plan",
            uniq_key=uniq_key,
            title=(data.get("title") or "收藏方案").strip(),
            payload=json.dumps(payload, ensure_ascii=False),
        )
        try:
            db.session.add(fav)
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise ApiException(400, "已收藏过该方案/榜单")
        return jsonify({"favorite": fav.to_dict()}), 201

    # 2. 收藏类型：single（单项目+单指标）
    full_name = (data.get("full_name") or "").strip()
    metric = (data.get("metric") or "").strip()
    platform = (data.get("platform") or "github").strip()

    if not full_name or not metric:
        raise ApiException(400, "single 收藏需要 full_name 和 metric")

    # 生成uniq_key（未传则自动生成）
    uniq_key = (data.get("uniq_key") or "").strip()
    if not uniq_key:
        uniq_key = build_single_key(full_name, metric, platform)

    fav = Favorite(
        user_id=uid,
        kind="single",
        uniq_key=uniq_key,
        full_name=full_name,
        metric=metric,
        platform=platform,
        title=(data.get("title") or "").strip(),
        url=(data.get("url") or "").strip(),
    )
    try:
        db.session.add(fav)
        db.session.commit()
    except Exception:
        db.session.rollback()
        raise ApiException(400, "已收藏过该项目指标")
    return jsonify({"favorite": fav.to_dict()}), 201

@favorites_bp.route("/<int:fav_id>", methods=["DELETE"])
@jwt_required()
def remove_favorite(fav_id: int):
    """删除收藏（防越权：仅能删除自己的收藏）"""
    uid = int(get_jwt_identity())
    # 同时过滤id和user_id，避免越权删除
    fav = Favorite.query.filter_by(id=fav_id, user_id=uid).first()
    if not fav:
        raise ApiException(404, "收藏不存在")
    
    db.session.delete(fav)
    db.session.commit()
    return jsonify({"message": "删除成功"}), 200