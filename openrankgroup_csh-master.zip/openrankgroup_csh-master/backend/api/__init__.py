# 从 opendigger.py 导出核心对象，供其他蓝图直接导入
from .opendigger import api_bp, ApiException
# 从 auth.py 导出鉴权蓝图，方便 main.py 统一注册（补充这行）
from .auth import auth_bp

# 导出所有蓝图，方便 main.py 统一注册
__all__ = ["api_bp", "ApiException", "auth_bp"]