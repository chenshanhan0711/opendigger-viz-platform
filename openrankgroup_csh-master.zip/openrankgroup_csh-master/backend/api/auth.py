from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from datetime import timedelta
from extensions import db
from models import User
from .opendigger import ApiException  # 复用统一异常类

# 鉴权蓝图（URL前缀：/api/auth）
auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")

# 异常处理器：统一返回JSON格式错误
@auth_bp.errorhandler(ApiException)
def handle_auth_exception(e: ApiException):
    return jsonify({"detail": e.detail}), e.status_code

@auth_bp.route("/register", methods=["POST"])
def register():
    """
    用户注册接口
    请求体：{"username": "xxx", "email": "xxx@xxx.com", "password": "xxx"}
    返回：注册成功信息 + 用户基本信息
    """
    # 1. 获取请求数据（兼容空数据场景）
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    email = (data.get("email") or "").strip()
    password = (data.get("password") or "").strip()

    # 2. 基础校验
    if not username or not email or not password:
        raise ApiException(400, "用户名、邮箱和密码不能为空")
    # 用户名长度校验（3-20位）
    if len(username) < 3 or len(username) > 20:
        raise ApiException(400, "用户名长度需在3-20位之间")
    # 密码强度校验（6-20位）
    if len(password) < 6 or len(password) > 20:
        raise ApiException(400, "密码长度需在6-20位之间")
    # 邮箱格式简单校验（含@和.）
    if "@" not in email or "." not in email.split("@")[-1]:
        raise ApiException(400, "请输入正确格式的邮箱")

    # 3. 唯一性校验（用户名/邮箱不重复）
    if User.query.filter_by(username=username).first():
        raise ApiException(400, "该用户名已被注册")
    if User.query.filter_by(email=email).first():
        raise ApiException(400, "该邮箱已被注册")

    # 4. 密码哈希存储（避免明文存储）
    user = User(username=username, email=email)
    user.set_password(password)  # 调用User模型的哈希方法

    # 5. 入库并提交
    try:
        db.session.add(user)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        raise ApiException(500, f"注册失败：{str(e)}")

    # 6. 返回注册成功信息
    return jsonify({
        "message": "注册成功，请登录",
        "user": user.to_dict()  # 调用User模型的序列化方法
    }), 201  # 201表示资源创建成功

@auth_bp.route("/login", methods=["POST"])
def login():
    """
    用户登录接口（支持用户名/邮箱登录）
    请求体：{"username": "用户名/邮箱", "password": "xxx"}
    返回：JWT Token + 用户基本信息
    """
    # 1. 获取请求数据
    data = request.get_json(silent=True) or {}
    account = (data.get("username") or "").strip()  # 账号：用户名或邮箱
    password = (data.get("password") or "").strip()

    # 2. 基础校验
    if not account or not password:
        raise ApiException(400, "用户名/邮箱 和 密码不能为空")

    # 3. 判断账号类型（邮箱含@，否则为用户名）
    if "@" in account:
        user = User.query.filter_by(email=account).first()
    else:
        user = User.query.filter_by(username=account).first()

    # 4. 验证用户存在性和密码正确性
    if not user:
        raise ApiException(404, "用户不存在")
    if not user.check_password(password):  # 调用User模型的密码校验方法
        raise ApiException(400, "密码错误")

    # 5. 生成JWT Token（有效期7天，附加用户信息）
    additional_claims = {
        "username": user.username,
        "email": user.email
    }
    access_token = create_access_token(
        identity=str(user.id),  # 存储用户ID（字符串类型，避免JWT序列化问题）
        additional_claims=additional_claims,
        expires_delta=timedelta(days=7)  # Token有效期
    )

    # 6. 返回登录成功信息
    return jsonify({
        "message": "登录成功",
        "access_token": access_token,
        "user": user.to_dict()
    }), 200

@auth_bp.route("/me", methods=["GET"])
@jwt_required()  # 需登录才能访问（自动验证Token）
def get_current_user():
    """
    获取当前登录用户信息（需携带JWT Token）
    请求头：Authorization: Bearer {access_token}
    返回：当前用户完整信息
    """
    # 1. 从Token中获取用户ID（之前存储的是字符串，需转为int）
    user_id = get_jwt_identity()  # 修正：需调用方法（原文档少了括号）
    user = User.query.get(int(user_id))

    # 2. 验证用户是否存在（避免Token有效但用户已删除的情况）
    if not user:
        raise ApiException(404, "用户不存在或已被删除")

    # 3. 返回用户信息
    return jsonify({"user": user.to_dict()}), 200