from datetime import datetime
import json
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, raw_password: str):
        """密码哈希存储"""
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        """密码校验"""
        return check_password_hash(self.password_hash, raw_password)

    def to_dict(self):
        """序列化返回给前端"""
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

class Favorite(db.Model):
    __tablename__ = "favorites"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    kind = db.Column(db.String(16), nullable=False, default="single", index=True)  # single/plan
    uniq_key = db.Column(db.String(300), nullable=False, index=True)  # 去重键
    full_name = db.Column(db.String(200), nullable=True)  # org/repo（仅single）
    metric = db.Column(db.String(64), nullable=True)  # 指标（仅single）
    platform = db.Column(db.String(32), nullable=True, default="github")  # 平台
    title = db.Column(db.String(200), nullable=True)  # 收藏标题
    url = db.Column(db.String(400), nullable=True)  # 项目链接
    payload = db.Column(db.Text, default="")  # 额外数据（plan类型JSON字符串）
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 唯一约束：同一用户同一uniq_key只能收藏一次
    __table_args__ = (
        db.UniqueConstraint("user_id", "uniq_key", name="uq_user_uniq_key"),
    )

    def to_dict(self):
        """序列化返回给前端"""
        payload_obj = {}
        if self.payload:
            try:
                payload_obj = json.loads(self.payload)
            except Exception:
                payload_obj = {}
        return {
            "id": self.id,
            "user_id": self.user_id,
            "kind": self.kind,
            "uniq_key": self.uniq_key,
            "full_name": self.full_name,
            "metric": self.metric,
            "platform": self.platform,
            "title": self.title,
            "url": self.url,
            "payload": payload_obj,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }