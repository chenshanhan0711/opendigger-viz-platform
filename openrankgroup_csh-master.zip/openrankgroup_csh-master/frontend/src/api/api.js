import axios from 'axios';

// 创建Axios实例（基础配置不变）
const http = axios.create({
  baseURL: 'http://127.0.0.1:8000',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  }
});

const httpOpenDigger = axios.create({
  baseURL: 'http://127.0.0.1:8001', // FastAPI 运行端口
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// 请求拦截器：自动携带JWT Token（不变）
http.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

httpOpenDigger.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const errMsg = error.response?.data?.detail || '数据请求失败';
    alert(errMsg);
    return Promise.reject(error);
  }
);

// 响应拦截器：统一错误提示（不变）
http.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const errMsg = error.response?.data?.detail || '操作失败';
    alert(errMsg);
    return Promise.reject(error);
  }
);

// 完善鉴权相关接口封装（与后端/auth接口对应）
export const authApi = {
  /**
   * 用户注册
   * @param {Object} payload - { username, email, password }
   * @returns 注册结果
   */
  register(payload) {
    return http.post('/api/auth/register', payload);
  },

  /**
   * 用户登录
   * @param {Object} payload - { username: '用户名/邮箱', password }
   * @returns Token + 用户信息
   */
  login(payload) {
    return http.post('/api/auth/login', payload);
  },

  /**
   * 获取当前登录用户信息
   * @returns 当前用户信息
   */
  getCurrentUser() {
    return http.get('/api/auth/me');
  },

  /**
   * 用户退出登录（前端清除Token）
   */
  logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('auth_user');
  }
};

// 收藏接口（不变，依赖登录鉴权）
export const favoritesApi = {
  list() {
    return http.get('/api/favorites');
  },
  add(payload) {
    return http.post('/api/favorites', payload);
  },
  remove(id) {
    return http.delete(`/api/favorites/${id}`);
  }
};

export const opendiggerApi = {
  // 获取支持的平台
  getPlatforms() {
    return httpOpenDigger.get('/api/platforms');
  },
  // 获取平台下的组织/用户
  getEntities(platform) {
    return httpOpenDigger.get(`/api/entities/${platform}`);
  },
  // 获取对应类型的指标（org/user）
  getMetrics(entityType) {
    return httpOpenDigger.get(`/api/metrics/${entityType}`);
  },
  // 获取组织下的可查询仓库
  getRepos(platform, org) {
    return httpOpenDigger.get(`/api/repos/${platform}/${org}`);
  },
  // 获取开发者指标数据（无仓库）
  getUserData(platform, entity, metric) {
    return httpOpenDigger.get(`/api/data/${platform}/${entity}/${metric}`);
  },
  // 获取仓库指标数据（需仓库）
  getRepoData(platform, entity, repo, metric) {
    return httpOpenDigger.get(`/api/data/${platform}/${entity}/${repo}/${metric}`);
  },
  // 保留你原有示例方法（兼容旧代码，若需要可删除）
  getRepoData_legacy(fullName) {
    return http.get(`/api/opendigger/repo/${fullName}`);
  }
};

export default http;