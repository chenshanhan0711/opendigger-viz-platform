<!-- src/App.vue -->
<template>
  <div class="app-layout">
    <header class="app-header">
      <div class="logo">Openpilot</div>
      <nav class="app-nav">
        <router-link to="/" class="nav-link">首页/推荐</router-link>
        <router-link to="/research" class="nav-link">筛选/搜索</router-link>
        <router-link to="/Favorites" class="nav-link">收藏</router-link>
        <router-link to="/start" class="nav-link">入门指南</router-link>

        <!-- 分隔线（视觉区分） -->
        <div class="nav-divider"></div>
        
        <!-- 动态鉴权导航项：未登录显示登录/注册，已登录显示用户名+退出 -->
        <template v-if="authStore.token">
          <!-- 登录后：显示用户名 + 退出按钮 -->
          <span class="nav-user">欢迎，{{ authStore.user?.username }}</span>
          <button class="nav-btn logout-btn" @click="handleLogout">退出登录</button>
        </template>
        <template v-else>
          <!-- 未登录：显示登录/注册链接 -->
          <router-link to="/login" class="nav-link auth-link">登录</router-link>
          <router-link to="/register" class="nav-link auth-link register-btn">注册</router-link>
        </template>
      </nav>
    </header>
    <main class="app-main-content">
      <router-view />
    </main>
  </div>
</template>

<script setup>
// 1. 导入鉴权Store和路由（原代码为空，新增）
import { useAuthStore } from '@/stores/auth';
import { useRouter } from 'vue-router';

// 2. 初始化Store和路由实例（新增）
const authStore = useAuthStore();
const router = useRouter();

// 3. 页面初始化时恢复登录状态（刷新页面后仍显示用户名，新增）
authStore.loadFromStorage();

// 4. 退出登录处理函数（新增）
const handleLogout = () => {
  authStore.logout(); // 清除Token和用户信息
  router.push('/'); // 退出后跳转到首页
};
</script>

<style scoped>
:root {
  --card-bg-color: #ffffff;       /* 导航栏背景色 */
  --text-color-dark: #1e293b;     /* logo/用户名文字色 */
  --text-color-light: #64748b;    /* 普通导航链接文字色 */
  --primary-color: #2563eb;       /* 主色调（注册/退出按钮背景） */
  --primary-color-light: #eff6ff; /* 激活链接背景色 */
  --primary-color-hover: #1d4ed8; /* 按钮hover色 */
}

.app-layout {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 2.5rem; /* 使用rem单位，更具弹性 */
  height: 70px;
  background-color: var(--card-bg-color);
  box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
  position: sticky;
  top: 0;
  z-index: 1000;
}

.logo {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--text-color-dark);
}

.app-nav {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}

.nav-link {
  padding: 0.5rem 1rem;
  font-size: 1rem;
  font-weight: 500;
  color: var(--text-color-light);
  text-decoration: none;
  border-radius: 6px;
  transition: background-color 0.2s, color 0.2s;
  position: relative;
}

/* 导航分隔线样式（新增） */
.nav-divider {
  width: 1px;
  height: 24px;
  background-color: #e2e8f0;
  margin: 0 0.5rem;
}

/* 登录用户信息样式（新增） */
.nav-user {
  padding: 0.5rem 1rem;
  font-size: 1rem;
  color: var(--text-color-dark);
  font-weight: 500;
}

/* 退出登录按钮样式（新增） */
.logout-btn {
  padding: 0.5rem 1rem;
  font-size: 1rem;
  font-weight: 500;
  color: white;
  background-color: var(--primary-color);
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.2s;
}

/* 注册按钮特殊样式（新增） */
.register-btn {
  background-color: var(--primary-color);
  color: white !important;
}

.nav-link:hover {
  background-color: #f1f5f9;
  color: var(--text-color-dark);
}

/* 激活状态的链接样式 */
.nav-link.router-link-exact-active {
  color: var(--primary-color);
  background-color: var(--primary-color-light);
}

/* 内容区 */
.app-main-content {
  flex-grow: 1; /* 占据剩余所有空间 */
  width: 100%;
  max-width: 1600px; /* 限制最大宽度，防止内容过散 */
  margin: 0 auto;
  padding: 2.5rem; /* 使用rem增加呼吸感 */
}
</style>