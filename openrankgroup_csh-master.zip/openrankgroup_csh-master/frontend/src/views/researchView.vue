<template>
  <div class="home-view">
    <header class="view-header">
      <h1>Openpilot 数据看板</h1>
      <p>按平台→组织/用户→指标→仓库（仅组织）动态筛选</p>
    </header>

    <!-- 五级联动筛选器（新增仓库下拉框） -->
    <div class="filter-panel">
      <!-- 1. 选择平台 -->
      <select v-model="selectedPlatform" @change="handlePlatformChange">
        <option value="">请选择平台</option>
        <option v-for="p in platforms" :key="p.value" :value="p.value">
          {{ p.label }}
        </option>
      </select>

      <!-- 2. 选择组织/用户 -->
      <select v-model="selectedEntity" @change="handleEntityChange" :disabled="!selectedPlatform">
        <option value="">请先选择平台</option>
        <option v-for="e in entities" :key="e.value" :value="e.value">
          {{ e.label }}（{{ e.type === 'org' ? '组织' : '用户' }}）
        </option>
      </select>

      <!-- 3. 选择指标（根据组织/用户类型动态变化） -->
      <select v-model="selectedMetric" @change="handleMetricChange" :disabled="!selectedEntity">
        <option value="">请先选择组织/用户</option>
        <option v-for="m in metrics" :key="m.value" :value="m.value">
          {{ m.label }}
        </option>
      </select>

      <!-- 4. 选择仓库（仅组织类型显示，下拉选择） -->
      <select
        v-if="selectedEntityType === 'org'"
        v-model="selectedRepo"
        :disabled="!selectedMetric"
      >
        <option value="">请先选择指标</option>
        <option v-for="repo in repos" :key="repo.value" :value="repo.value">
          {{ repo.label }}（{{ repo.description }}）
        </option>
      </select>

      <!-- 添加图表按钮 -->
      <button
        @click="addChart"
        :disabled="!selectedPlatform || !selectedEntity || !selectedMetric || (selectedEntityType === 'org' && !selectedRepo)"
      >
        添加图表
      </button>
    </div>

    <!-- 图表展示区 -->
    <div class="chart-grid">
      <!-- 动态添加的图表 -->
      <div v-for="chart in dynamicCharts" :key="chart.id" class="chart-card">
        <div class="chart-header">
          <h3>{{ chart.title }}</h3>
          <button @click="removeChart(chart.id)">×</button>
        </div>
        <RepoChart 
          :platform="chart.platform"
          :org="chart.entity"
          :repo="chart.repo"
          :metric="chart.metric"
          :title="chart.title"
          :loading="chart.loading"
          :error="chart.error"
          :chart-data="chart.data"
        />
      </div>

      <!-- 无图表提示 -->
      <div v-if="dynamicCharts.length === 0" class="empty-tip">
        暂无图表，可通过上方筛选器手动添加，或通过下方开源项目筛选自动生成～
      </div>
    </div>

    <!-- 开源项目筛选区（新增下拉框选项 + 交互优化） -->
    <div class="project-filters">
      <h3>开源项目</h3>
      <!-- 技术栈下拉框（新增常用选项 + 绑定选中值） -->
      <div class="filter-row">
        <label>技术栈：</label>
        <select class="filter-select" v-model="selectedTech">
          <option value="">请选择技术栈</option>
          <option value="vue">Vue</option>
          <option value="HTML">HTML</option>
          <option value="CSS">CSS</option>
          <option value="python">Python</option>
          <option value="C">C </option>
          <option value="javascript">JavaScript</option>
        </select>
      </div>

      <!-- Issue响应时间下拉框（新增常用选项 + 绑定选中值） -->
      <div class="filter-row">
        <label>issue 响应时间：</label>
        <select class="filter-select" v-model="selectedIssueTime">
          <option value="">请选择响应时间</option>
          <option value="super-fast">超快速（< 6小时）</option>
          <option value="fast">快速（6-24小时）</option>
          <option value="medium">中等（1-3天）</option>
          <option value="slow">较慢（3-7天）</option>
          <option value="very-slow">极慢（> 7天）</option>
        </select>
      </div>

      <!-- 难度等级（选中高亮） -->
      <div class="filter-row">
        <label>难度等级：</label>
        <button class="level-btn" :class="{ active: selectedDifficulty === 'low' }" @click="selectedDifficulty = 'low'">低</button>
        <button class="level-btn" :class="{ active: selectedDifficulty === 'medium' }" @click="selectedDifficulty = 'medium'">中</button>
        <button class="level-btn" :class="{ active: selectedDifficulty === 'high' }" @click="selectedDifficulty = 'high'">高</button>
      </div>

      <!-- 活跃度（选中高亮） -->
      <div class="filter-row">
        <label>活跃度：</label>
        <button class="level-btn" :class="{ active: selectedActivity === 'low' }" @click="selectedActivity = 'low'">低</button>
        <button class="level-btn" :class="{ active: selectedActivity === 'medium' }" @click="selectedActivity = 'medium'">中</button>
        <button class="level-btn" :class="{ active: selectedActivity === 'high' }" @click="selectedActivity = 'high'">高</button>
      </div>
    </div>

    <!-- 操作按钮（筛选/重置逻辑） -->
    <div class="action-btns">
      <button class="filter-btn" @click="handleFilter" :disabled="isFilterLoading">
        {{ isFilterLoading ? '筛选中...' : '筛选' }}
      </button>
      <button class="reset-btn" @click="handleReset">重置</button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { opendiggerApi } from '../api/api';
import RepoChart from '../components/RepoChart.vue';
// 导入 Pinia 图表存储
import { useChartStore } from '../stores/chartStore';
import { storeToRefs } from 'pinia'; // 用于响应式解构 Pinia 状态

// 初始化 Pinia 存储
const chartStore = useChartStore();
// 响应式解构 dynamicCharts（替代本地 ref 变量）
const { dynamicCharts } = storeToRefs(chartStore);

// 筛选器状态（新增 selectedRepo 存储选中的仓库）
const selectedPlatform = ref('');
const selectedEntity = ref('');
const selectedMetric = ref('');
const selectedRepo = ref(''); // 替换原 repoName，改为下拉选择

// 元数据列表（新增 repos 存储组织下的仓库列表）
const platforms = ref([]);
const entities = ref([]);
const metrics = ref([]);
const repos = ref([]); // 组织下的可查询仓库

// 当前选择的实体类型（org/user）
const selectedEntityType = ref('');

// 图表 ID 计数器（从 Pinia 中读取最大 ID，避免重复）
const chartId = ref(100);

// ---------------------- 开源项目筛选相关状态 ----------------------
const selectedTech = ref('');         // 选中的技术栈
const selectedIssueTime = ref('');    // 选中的响应时间
const selectedDifficulty = ref('');   // 选中的难度
const selectedActivity = ref('');     // 选中的活跃度
const isFilterLoading = ref(false);   // 筛选加载状态

onMounted(async () => {
  // 1. 先从 Pinia 计算最大图表 ID，避免重复
  if (dynamicCharts.value && dynamicCharts.value.length > 0) {
    const maxId = Math.max(...dynamicCharts.value.map(chart => chart.id));
    chartId.value = maxId + 1; // 修正：ref 变量赋值需用 .value
  }

  // 2. 再加载平台列表
  const res = await opendiggerApi.getPlatforms();
  platforms.value = res.data;
});

// 1. 选择平台后：加载组织/用户列表（不变）
const handlePlatformChange = async () => {
  if (!selectedPlatform.value) {
    entities.value = [];
    metrics.value = [];
    repos.value = [];
    selectedEntity.value = '';
    selectedMetric.value = '';
    selectedRepo.value = '';
    selectedEntityType.value = '';
    return;
  }
  const res = await opendiggerApi.getEntities(selectedPlatform.value);
  entities.value = res.data;
  // 重置后续选择
  metrics.value = [];
  repos.value = [];
  selectedEntity.value = '';
  selectedMetric.value = '';
  selectedRepo.value = '';
  selectedEntityType.value = '';
};

// 2. 选择组织/用户后：加载对应类型的指标（不变）
const handleEntityChange = async () => {
  if (!selectedEntity.value) {
    metrics.value = [];
    repos.value = [];
    selectedMetric.value = '';
    selectedRepo.value = '';
    selectedEntityType.value = '';
    return;
  }
  // 获取当前实体的类型（org/user）
  const entity = entities.value.find(e => e.value === selectedEntity.value);
  selectedEntityType.value = entity.type;
  
  // 加载对应类型的指标
  const res = await opendiggerApi.getMetrics(entity.type);
  metrics.value = res.data;
  
  // 重置仓库选择（如果是组织类型，后续加载仓库；用户类型清空仓库）
  repos.value = [];
  selectedRepo.value = '';
};

// 3. 新增：选择指标后，若为组织类型则加载仓库列表
const handleMetricChange = async () => {
  if (!selectedMetric.value || selectedEntityType.value !== 'org') {
    repos.value = [];
    selectedRepo.value = '';
    return;
  }
  // 组织类型：加载该组织下的可查询仓库
  try {
    const res = await opendiggerApi.getRepos(selectedPlatform.value, selectedEntity.value);
    repos.value = res.data;
  } catch (err) {
    console.error('加载仓库列表失败：', err);
    repos.value = [];
  }
};

// 4. 添加图表（修改 repo 为 selectedRepo）
const addChart = async () => {
  try {
    // 构建图表标题
    const platformLabel = platforms.value.find(p => p.value === selectedPlatform.value).label;
    const entityLabel = entities.value.find(e => e.value === selectedEntity.value).label;
    const metricLabel = metrics.value.find(m => m.value === selectedMetric.value).label;
    let chartTitle;
    
    if (selectedEntityType.value === 'org') {
      // 组织+仓库：拼接仓库名
      const repoLabel = repos.value.find(r => r.value === selectedRepo.value).label;
      chartTitle = `${platformLabel} · ${entityLabel}/${repoLabel} · ${metricLabel}`;
    } else {
      // 用户：无仓库
      chartTitle = `${platformLabel} · ${entityLabel} · ${metricLabel}`;
    }

    // 新增图表（加载状态）
    const newChart = {
      id: chartId.value++,
      platform: selectedPlatform.value,
      entity: selectedEntity.value,
      entityType: selectedEntityType.value,
      metric: selectedMetric.value,
      repo: selectedRepo.value, // 传递选中的仓库
      title: chartTitle,
      loading: true,
      error: '',
      data: []
    };
    // 关键修改：添加到 Pinia 存储（而非本地数组）
    chartStore.addChart(newChart);

    // 请求数据
    let res;
    if (selectedEntityType.value === 'org') {
      // 仓库指标：传递选中的仓库
      res = await opendiggerApi.getRepoData(
        selectedPlatform.value,
        selectedEntity.value,
        selectedRepo.value,
        selectedMetric.value
      );
    } else {
      // 开发者指标：无需仓库
      res = await opendiggerApi.getUserData(
        selectedPlatform.value,
        selectedEntity.value,
        selectedMetric.value
      );
    }

    // 更新图表数据
    const chartIndex = dynamicCharts.value.findIndex(c => c.id === newChart.id);
    if (chartIndex !== -1) {
      dynamicCharts.value[chartIndex] = {
        ...dynamicCharts.value[chartIndex],
        loading: false,
        data: res.data.data
      };
    }
  } catch (err) {
    const chartIndex = dynamicCharts.value.findIndex(c => c.id === chartId.value - 1);
    if (chartIndex !== -1) {
      let errorMsg = err.message || '数据加载失败';
      // 针对 OpenDigger 404 错误，给出明确提示
      if (err.response && err.response.status === 404) {
        errorMsg = '该指标官方未开放（404），请选择其他指标';
      }
      dynamicCharts.value[chartIndex] = {
        ...dynamicCharts.value[chartIndex],
        loading: false,
        error: errorMsg
      };
    }
    console.error('添加图表失败：', err);
  }
};

// 5. 移除图表（不变）
const removeChart = (id) => {
  chartStore.removeChart(id); // 直接调用 Pinia 动作删除
};

// ---------------------- 开源项目筛选核心逻辑 ----------------------
const handleFilter = async () => {
  // 1. 校验：至少选择一个筛选条件
  if (!selectedTech.value && !selectedIssueTime.value && !selectedDifficulty.value && !selectedActivity.value) {
    alert('请至少选择一个筛选条件！');
    return;
  }

  try {
    isFilterLoading.value = true;

    // 2. 调用接口获取匹配的开源项目列表（需后端支持）
    const filterParams = {
      tech: selectedTech.value,
      issueTime: selectedIssueTime.value,
      difficulty: selectedDifficulty.value,
      activity: selectedActivity.value
    };
    const projectRes = await opendiggerApi.getFilteredProjects(filterParams);
    const matchedProjects = projectRes.data || [];

    if (matchedProjects.length === 0) {
      alert('未找到符合条件的开源项目！');
      return;
    }

    // 3. 清空现有图表（可选：保留则注释此行）
    chartStore.clearCharts();

    // 4. 遍历项目生成图表（默认指标：星标数）
    const defaultMetric = 'stars';
    const defaultMetricLabel = '星标数';

    for (const project of matchedProjects) {
      const { platform, org, repo } = project;
      if (!platform || !org || !repo) continue;

      const platformLabel = platforms.value.find(p => p.value === platform)?.label || platform;
      const chartTitle = `${platformLabel} · ${org}/${repo} · ${defaultMetricLabel}`;

      // 创建图表（加载状态）
      const newChart = {
        id: chartId.value++,
        platform: platform,
        entity: org,
        entityType: 'org',
        metric: defaultMetric,
        repo: repo,
        title: chartTitle,
        loading: true,
        error: '',
        data: []
      };
      chartStore.addChart(newChart);

      // 5. 请求指标数据
      try {
        const dataRes = await opendiggerApi.getRepoData(platform, org, repo, defaultMetric);
        const chartIndex = dynamicCharts.value.findIndex(c => c.id === newChart.id);
        if (chartIndex !== -1) {
          dynamicCharts.value[chartIndex] = {
            ...dynamicCharts.value[chartIndex],
            loading: false,
            data: dataRes.data.data
          };
        }
      } catch (err) {
        const chartIndex = dynamicCharts.value.findIndex(c => c.id === newChart.id);
        if (chartIndex !== -1) {
          dynamicCharts.value[chartIndex] = {
            ...dynamicCharts.value[chartIndex],
            loading: false,
            error: `加载失败：${err.message}`
          };
        }
      }
    }
  } catch (err) {
    console.error('筛选失败：', err);
    alert(`筛选出错：${err.message}`);
  } finally {
    isFilterLoading.value = false;
  }
};

// ---------------------- 重置筛选条件 ----------------------
const handleReset = () => {
  selectedTech.value = '';
  selectedIssueTime.value = '';
  selectedDifficulty.value = '';
  selectedActivity.value = '';
};
</script>

<style scoped>

.home-view {
  padding: 20px;
  font-family: "微软雅黑", sans-serif;
  /* 核心：背景线性渐变（从左到右，浅蓝→浅紫→浅粉） */
  background: linear-gradient(to right, #a0c4ff, #bde0fe, #c8b6ff);
  /* 保留你原有所有布局属性，确保铺满网页 */
  min-height: 100vh;
  margin: 0 !important;
  width: 100% !important;
  box-sizing: border-box !important;
  position: relative;
}
/* 基础样式 */
.view-header { text-align: center; margin-bottom: 2rem; }
.filter-panel { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 2rem; align-items: center; }
.filter-panel select { padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; min-width: 180px; }
.filter-panel button { padding: 0.5rem 1rem; background: #2563eb; color: white; border: none; border-radius: 4px; cursor: pointer; }
.filter-panel button:disabled { background: #94a3b8; cursor: not-allowed; }

/* 图表展示区样式 */
.chart-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(450px, 1fr)); gap: 1.5rem; }
.chart-card { background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 1.2rem; }
.chart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
.chart-header h3 { margin: 0; font-size: 1.1rem; color: #1e293b; }
.chart-header button { background: transparent; border: none; color: #94a3b8; cursor: pointer; font-size: 1.2rem; }
.chart-header button:hover { color: #ef4444; }

/* 空提示样式 */
.empty-tip { grid-column: 1 / -1; text-align: center; padding: 3rem; color: #64748b; }

/* 开源项目筛选区样式 */
.project-filters {
  margin: 3rem 0; /* 增加上下间距 */
  padding: 2rem; /* 增加内边距，让区域更宽 */
  border: 1px solid #eee; /* 可选：加边框区分区域 */
  border-radius: 8px;
}

/* 筛选区标题样式 */
.project-filters h3 {
  font-size: 1.5rem; /* 标题字体放大 */
  margin-bottom: 2rem; /* 标题与内容间距增大 */
}

/* 筛选行样式 */
.filter-row {
  margin: 1.5rem 0; /* 行间距增大 */
  display: flex;
  align-items: center;
  gap: 1.5rem; /* 标签与控件的间距增大 */
  font-size: 1.1rem; /* 行内字体放大 */
}

/* 下拉框样式 */
.filter-select {
  padding: 0.8rem 1.2rem; /* 下拉框内边距增大 */
  font-size: 1.1rem; /* 下拉框字体放大 */
  min-width: 200px; /* 下拉框宽度增大 */
  border: 1px solid #ddd;
  border-radius: 6px;
}

/* 难度/活跃度按钮样式（含选中高亮） */
.level-btn {
  padding: 0.6rem 1.5rem; /* 按钮内边距增大 */
  font-size: 1.1rem; /* 按钮字体放大 */
  border: 1px solid #ddd;
  border-radius: 6px;
  background: #f5f5f5;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-right: 0.5rem;
}

/* 选中高亮效果 */
.level-btn.active {
  background: #2563eb;
  color: white;
  border-color: #2563eb;
  box-shadow: 0 2px 8px rgba(37, 99, 235, 0.2);
}

/* 按钮hover效果 */
.level-btn:hover:not(.active) {
  border-color: #2563eb;
  background: #f8fafc;
  color: #2563eb;
}

/* 操作按钮样式 */
.action-btns {
  display: flex;
  gap: 1.5rem; /* 按钮间距增大 */
  justify-content: flex-end;
  margin-top: 2rem; /* 与筛选区的间距增大 */
}

.filter-btn, .reset-btn {
  padding: 0.8rem 2rem; /* 按钮内边距增大 */
  font-size: 1.1rem; /* 按钮字体放大 */
  border-radius: 6px;
  transition: background 0.3s;
}

/* 筛选按钮样式 */
.filter-btn {
  background: #2563eb;
  color: white;
  border: none;
}

.filter-btn:hover:not(:disabled) {
  background: #1d4ed8;
}

.filter-btn:disabled {
  background: #94a3b8;
  cursor: not-allowed;
}

/* 重置按钮样式 */
.reset-btn {
  background: #f1f5f9;
  color: #1e293b;
  border: 1px solid #ddd;
}

.reset-btn:hover {
  background: #e2e8f0;
}

/* 修复最后一个按钮的右边距 */
.level-btn:last-child {
  margin-right: 0;
}

</style>