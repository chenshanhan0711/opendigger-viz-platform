<template>
  <div class="app-container">
    <!-- 外层容器：调整边距让框往上移 -->
    <div class="openpilot-container">
      <!-- 主体区域：左侧4个导航（无留白） + 右侧内容 -->
      <div class="main-layout">
        <!-- 左侧导航栏：加宽，文字加粗 -->
        <div class="side-nav">
          <div class="nav-list">
            <div class="nav-item" @click="activeNav = 'issue'">issue参与规范</div>
            <div class="nav-item" @click="activeNav = 'etiquette'">开源社区礼仪</div>
            <div class="nav-item" @click="activeNav = 'config'">环境配置指南</div>
            <div class="nav-item" @click="activeNav = 'other'">其它问题</div>
          </div>
        </div>

        <!-- 右侧内容区 -->
        <div class="content-area">
          <template v-if="activeNav === 'issue'">
            <h3>issue参与规范</h3>
            <p>1. 提交issue前请先通过搜索确认无重复问题，避免资源浪费</p>
            <p>2. 标题需简洁明了，准确概括问题核心（例：【Bug】XXX功能在Chrome浏览器下报错）</p>
            <p>3. 详细描述复现步骤、使用环境（系统/浏览器/版本）和预期结果</p>
            <p>4. 附上相关日志、截图、录屏等辅助信息，加速问题定位</p>
            <p>5. 问题解决后请及时关闭issue，并可补充解决方案供他人参考</p>
          </template>
          <template v-else-if="activeNav === 'etiquette'">
            <h3>开源社区礼仪</h3>
            <p>1. 尊重每位贡献者的劳动成果，理性沟通，避免情绪化表达</p>
            <p>2. 不发布无关广告、恶意链接、人身攻击等违规内容</p>
            <p>3. 积极参与社区讨论，对他人的问题和贡献给予正面反馈</p>
            <p>4. 遵循社区代码规范和贡献指南，提交PR前确保代码可运行且无冗余</p>
            <p>5. 遇到分歧时以解决问题为目标，求同存异，共同维护友好的社区氛围</p>
          </template>
          <template v-else-if="activeNav === 'config'">
            <h3>环境配置指南</h3>
            <p>1. 前置要求：Node.js（v16+）、npm（v8+）或yarn（v1.22+）</p>
            <p>2. 克隆仓库：git clone https://github.com/openpilot/openpilot.git</p>
            <p>3. 进入项目目录：cd openpilot</p>
            <p>4. 安装依赖：npm install（国内用户可配置淘宝镜像：npm config set registry https://registry.npm.taobao.org）</p>
            <p>5. 启动开发环境：npm run dev（默认端口3000，访问http://localhost:3000）</p>
            <p>6. 构建生产版本：npm run build（构建结果输出到dist目录）</p>
            <p>7. 运行测试：npm run test（确保代码无语法错误和逻辑问题）</p>
          </template>
          <template v-else-if="activeNav === 'other'">
            <h3>其它问题</h3>
            <p>1. 如有未覆盖的问题，可先查看项目Wiki文档：https://github.com/openpilot/openpilot/wiki</p>
            <p>2. 加入社区QQ群：123456789（备注：Openpilot交流）</p>
            <p>3. 发送邮件至官方支持：support@openpilot.com（24小时内回复）</p>
            <p>4. 参与GitHub Discussion：https://github.com/openpilot/discussions</p>
            <p>5. 关注官方公众号：Openpilot开源社区（获取最新动态和教程）</p>
          </template>
          <template v-else>
            <p>请选择左侧导航项查看对应内容</p>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
const activeNav = ref('') // 记录当前选中的导航项
</script>

<style scoped>
/* 全局样式：统一微软雅黑字体 + 清除默认边距 */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Microsoft YaHei", "微软雅黑", sans-serif;
}

/* 根容器：渐变背景 + 框往上移 */
.app-container {
  width: 100vw;
  height: 100vh;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 20px 30px 60px;
  overflow: hidden;
  background: linear-gradient(to right, #a0c4ff, #bde0fe, #c8b6ff);
}

/* 主容器：框内加浅色系纯色背景 */
.openpilot-container {
  width: 100%;
  max-width: 1700px;
  height: 100%;
  max-height: 820px;
  border: 1px solid #333;
  display: flex;
  flex-direction: column;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  /* 框内背景色：浅蓝（柔和不刺眼），可替换成你想要的颜色 */
  background-color: #f0f8fb; 
}

/* 主体布局：占满剩余高度 */
.main-layout {
  display: flex;
  flex: 1;
  overflow: hidden;
}

/* 左侧导航栏：加宽+加粗 */
.side-nav {
  width: 300px;
  border-right: 1px solid #333;
  /* 左侧导航背景可稍深一点，区分层次 */
  background-color: #e8f4f8; 
  display: flex;
  flex-direction: column;
}

.nav-list {
  display: flex;
  flex-direction: column;
  flex: 1;
}

.nav-item {
  flex: 1;
  display: flex;
  align-items: center;
  padding: 0 28px;
  border-bottom: 1px solid #333;
  font-size: 22px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s;
}

.nav-item:last-child {
  border-bottom: none;
}

.nav-item:hover {
  background-color: #d4e9f1;
}

/* 右侧内容区：文字放大 + 浅背景 */
.content-area {
  flex: 1;
  padding: 40px 50px;
  /* 内容区背景和框体背景一致，整体统一 */
  background-color: #f0f8fb; 
  overflow-y: auto;
}

.content-area h3 {
  font-size: 28px;
  margin-bottom: 30px;
  color: #333;
}

.content-area p {
  font-size: 21px;
  margin-bottom: 20px;
  line-height: 1.8;
  color: #444;
}
</style>