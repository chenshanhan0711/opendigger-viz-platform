<template>
  <div class="layout-container">
    <!-- 内容区域：两个并列模块 -->
    <main class="content">
      <!-- 技术栈分布模块组 -->
      <div class="module-group">
        <!-- 左侧模块：筛选+饼图 -->
        <div class="module">
          <!-- 筛选组件 -->
          <div class="tech-filter">
            <label class="filter-label">技术方向：</label>
            <select 
              class="filter-select" 
              v-model="selectedTech" 
              @change="handleTechChange"
            >
              <option value="frontend">前端</option>
              <option value="backend">后端</option>
              <option value="algorithm">算法</option>
            </select>
          </div>
          <!-- 饼图容器 -->
          <div ref="pieChartRef" class="echarts-pie"></div>
        </div>
        <!-- 可点击的技术栈分布文字框 -->
        <div class="module-text tech-stack-box" @click="goToTechDetail">
          技术栈分布
        </div>
      </div>

      <!-- 热门项目模块组 -->
      <div class="module-group">
        <div class="module">
          <!-- 热门项目排行榜 -->
          <div class="project-ranking">
            <h4 class="ranking-title">热门项目TOP3</h4>
            <ul class="ranking-list">
              <li class="ranking-item">1. OpenDigger（活跃度：98）</li>
              <li class="ranking-item">2. Vue生态（活跃度：92）</li>
              <li class="ranking-item">3. ECharts示例（活跃度：86）</li>
            </ul>
          </div>
          <!-- 趋势图容器 -->
          <div ref="trendChartRef" class="echarts-trend"></div>
        </div>
        <div class="module-text">热门项目活跃度趋势</div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import * as echarts from 'echarts'
import { useRouter } from 'vue-router'

// 图表容器Ref
const pieChartRef = ref(null)
const trendChartRef = ref(null)
// 选中的技术方向（默认前端）
const selectedTech = ref('frontend')
// 饼图实例缓存
const pieChartInstance = ref(null)

// 不同技术方向对应的饼图数据
const techDataMap = {
  frontend: [
    { name: 'HTML', value: 35 },
    { name: 'Javascript', value: 40 },
    { name: 'CSS', value: 15 },
    { name: 'Vue', value: 25 },
    { name: 'React', value: 20 },
    { name: 'TypeScript', value: 18 }
  ],
  backend: [
    { name: 'Python', value: 45 },
    { name: 'Java', value: 50 },
    { name: 'Go', value: 30 },
    { name: 'PHP', value: 15 },
    { name: 'Node.js', value: 25 },
    { name: 'C#', value: 10 }
  ],
  algorithm: [
    { name: 'Python', value: 60 },
    { name: 'C++', value: 55 },
    { name: 'Java', value: 35 },
    { name: 'Go', value: 20 },
    { name: 'R', value: 15 },
    { name: 'MATLAB', value: 10 }
  ]
}

// 路由实例
const router = useRouter()

// 技术栈详情页跳转方法
const goToTechDetail = () => {
  router.push('/tech-stack-detail').catch(err => {
    console.error('跳转技术栈详情页失败：', err)
  })
}

// 导航按钮点击事件（保留原有逻辑）
const handleNavClick = (navType) => {
  console.log(`点击了${navType}按钮`);
};

// 技术方向切换 - 更新饼图数据
const handleTechChange = () => {
  if (pieChartInstance.value) {
    pieChartInstance.value.setOption({
      series: [{ data: techDataMap[selectedTech.value] }]
    })
  }
}

// 初始化技术栈饼图
const initPieChart = () => {
  if (!pieChartRef.value) return
  pieChartInstance.value = echarts.init(pieChartRef.value)
  
  const pieOption = {
    title: {
      text: '技术栈占比分布',
      left: 'center',
      textStyle: { fontSize: 16, fontWeight: 'bold' }
    },
    tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
    legend: {
      orient: 'vertical',
      right: 20,
      top: 'center',
      itemWidth: 16,
      itemHeight: 16,
      textStyle: { fontSize: 16 }
    },
    series: [
      {
        name: '技术栈',
        type: 'pie',
        radius: ['25%', '80%'],
        center: ['35%', '55%'],
        data: techDataMap[selectedTech.value],
        label: { show: false },
        labelLine: { show: false }
      }
    ]
  }

  pieChartInstance.value.setOption(pieOption)
  const resizeHandler = () => pieChartInstance.value.resize()
  window.addEventListener('resize', resizeHandler)
  
  onUnmounted(() => {
    window.removeEventListener('resize', resizeHandler)
    pieChartInstance.value.dispose()
  })
}

// 初始化热门项目趋势图
const initTrendChart = () => {
  if (!trendChartRef.value) return
  const trendChart = echarts.init(trendChartRef.value)
  
  const trendOption = {
    title: {
      text: 'TOP3项目活跃度趋势',
      left: 'center',
      textStyle: { fontSize: 16, fontWeight: 'bold' }
    },
    tooltip: { trigger: 'axis' },
    legend: {
      data: ['OpenDigger', 'Vue生态', 'ECharts示例'],
      left: 'center',
      bottom: 0
    },
    xAxis: {
      type: 'category',
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
      axisLabel: { fontSize: 12 }
    },
    yAxis: {
      type: 'value',
      name: '活跃度',
      nameTextStyle: { fontSize: 12 }
    },
    series: [
      { name: 'OpenDigger', type: 'line', smooth: true, data: [85, 88, 92, 95, 98, 96, 97] },
      { name: 'Vue生态', type: 'line', smooth: true, data: [78, 82, 85, 88, 92, 90, 91] },
      { name: 'ECharts示例', type: 'line', smooth: true, data: [70, 75, 78, 82, 86, 84, 85] }
    ]
  }

  trendChart.setOption(trendOption)
  const resizeHandler = () => trendChart.resize()
  window.addEventListener('resize', resizeHandler)
  
  onUnmounted(() => {
    window.removeEventListener('resize', resizeHandler)
    trendChart.dispose()
  })
}

// 挂载时初始化图表
onMounted(() => {
  initPieChart()
  initTrendChart()
})
</script>

<style scoped>
/* 全局容器样式 */
.layout-container {
  padding: 20px;
  font-family: "微软雅黑", sans-serif;
  background: linear-gradient(to right, #a0c4ff, #bde0fe, #c8b6ff);
  min-height: 100vh;
  margin: 0 !important;
  width: 100% !important;
  box-sizing: border-box !important;
  position: relative;
}

/* 内容区域布局 */
.content {
  display: flex;
  gap: 40px;
  flex-wrap: wrap;
}

/* 模块组样式 */
.module-group {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 30px;
}

/* 模块样式 */
.module {
  width: 700px;
  height: 500px;
  border: 3px solid #ccc;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

/* 通用文字样式 */
.module-text {
  padding: 4px 8px;
  border-radius: 4px;
  color: #333;
  font-weight: 700;
  font-size: 28px;
  text-align: center;
}

/* 技术栈分布文字框样式 */
.tech-stack-box {
  cursor: pointer;
  border: 2px solid #ccc;
  padding: 8px 20px;
  border-radius: 6px;
  background: white;
  transition: all 0.2s ease;
}

.tech-stack-box:hover {
  border-color: #888;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  transform: translateY(-2px);
}

/* 筛选组件样式 */
.tech-filter {
  margin-bottom: 20px;
  padding: 10px;
  text-align: center;
}

.filter-label {
  font-size: 16px;
  color: #333;
  margin-right: 10px;
  font-weight: 500;
}

.filter-select {
  padding: 6px 12px;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 14px;
  color: #333;
  cursor: pointer;
}

/* 饼图容器 */
.echarts-pie {
  flex: 1;
  width: 100%;
}

/* 排行榜样式 */
.project-ranking {
  margin-bottom: 10px;
  padding: 10px;
}

.ranking-title {
  font-size: 18px;
  color: #333;
  text-align: center;
  margin-bottom: 15px;
  font-weight: 700;
}

.ranking-list {
  list-style: none;
  padding-left: 0;
  text-align: center;
}

.ranking-item {
  font-size: 16px;
  color: #333;
  margin-bottom: 8px;
}

/* 趋势图容器 */
.echarts-trend {
  flex: 1;
  width: 100%;
}

/* 头部/导航样式（保留原有） */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border-bottom: 1px solid #eee;
  margin-bottom: 60px;
}

.logo-title {
  padding: 8px 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
}

.nav {
  display: flex;
  gap: 30px;
}

.nav-item {
  padding: 6px 12px;
  border-radius: 4px;
  cursor: pointer;
  color: #333;
  transition: background-color 0.2s;
}

.nav-item:hover {
  background-color: #f0c800;
}
</style>