<template>
  <div class="login-container">
    <div class="login-card">
      <h2>用户登录</h2>
      <!-- 错误提示 -->
      <div v-if="authStore.error" class="error-tip">{{ authStore.error }}</div>
      
      <!-- 登录表单 -->
      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label>用户名/邮箱</label>
          <input
            type="text"
            v-model="loginForm.username"
            required
            placeholder="请输入用户名或邮箱"
          >
        </div>
        <div class="form-group">
          <label>密码</label>
          <input
            type="password"
            v-model="loginForm.password"
            required
            placeholder="请输入密码（6-20位）"
          >
        </div>
        <button type="submit" :disabled="authStore.loading" class="login-btn">
          {{ authStore.loading ? '登录中...' : '登录' }}
        </button>
      </form>
      
      <!-- 跳转注册 -->
      <div class="register-link">
        还没有账号？<router-link to="/register">立即注册</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useAuthStore } from '@/stores/auth';
import { useRouter } from 'vue-router';

const authStore = useAuthStore();
const router = useRouter();

// 登录表单数据
const loginForm = ref({
  username: '',
  password: ''
});

// 登录处理
const handleLogin = async () => {
  try {
    const success = await authStore.login(loginForm.value);
    if (success) {
      // 登录成功后跳转：优先跳转到登录前的页面，否则跳首页
      const redirect = router.currentRoute.value.query.redirect || '/';
      router.push(redirect);
    }
  } catch (err) {
    // 错误已在authStore中处理，无需额外操作
  }
};
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: calc(100vh - 70px);  /* 减去导航栏高度 */
  background: linear-gradient(to right, #a0c4ff, #bde0fe, #c8b6ff);
  padding: 20px;
}

.login-card {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  width: 100%;
  max-width: 400px;
}

.login-card h2 {
  text-align: center;
  margin-bottom: 1.5rem;
  color: #1e293b;
}

.error-tip {
  color: #ef4444;
  text-align: center;
  margin-bottom: 1rem;
}

.form-group {
  margin-bottom: 1rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: #475569;
  font-weight: 500;
}

.form-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #e2e8f0;
  border-radius: 4px;
  font-size: 1rem;
}

.login-btn {
  width: 100%;
  padding: 0.75rem;
  background: #2563eb;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.login-btn:disabled {
  background: #94a3b8;
  cursor: not-allowed;
}

.register-link {
  text-align: center;
  margin-top: 1rem;
  color: #64748b;
}

.register-link a {
  color: #2563eb;
  text-decoration: none;
}

.register-link a:hover {
  text-decoration: underline;
}
</style>