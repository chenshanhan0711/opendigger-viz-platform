<!-- src/views/FavoritesView.vue -->
<template>
  <div class="favorites-view">
    <header class="view-header">
      <h2>我的收藏项目</h2>
    </header>
    <div v-if="favoritesStore.favoriteProjects.length === 0" class="empty-state">
      <p>暂无收藏项目</p>
      <span>去首页点击图表右上角的 ❤️ 按钮收藏你感兴趣的图表吧！</span>
    </div>
    <div v-else class="favorites-grid">
      <div v-for="project in favoritesStore.favoriteProjects" :key="`${project.fullName}-${project.metric}`" class="favorite-card">
        <div class="card-header">
          <div class="card-title-group">
            <h3>{{ project.title }}</h3>
            <a :href="project.url" target="_blank" rel="noopener noreferrer">{{ project.fullName }}</a>
          </div>
          <button @click="handleRemove(project)" class="remove-btn" title="取消收藏">×</button>
        </div>
        <div class="card-chart">
          <RepoChart :platform="project.platform" :org="project.fullName.split('/')[0]" :repo="project.fullName.split('/')[1]" :metric="project.metric" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useFavoritesStore } from '../stores/favorites';
import RepoChart from '../components/RepoChart.vue';
const favoritesStore = useFavoritesStore();

const handleRemove = (project) => {
  if (confirm(`确定要取消收藏「${project.title}」吗？`)) {
    favoritesStore.removeFavorite(`${project.fullName}-${project.metric}`);
  }
};
</script>

<style scoped>
  /* 保留你原有所有样式不变 */
/* 全局容器样式 */
/* 全局容器样式（背景渐变色 + 铺满整个网页） */
.favorites-view {
  padding: 20px;
  font-family: "微软雅黑", sans-serif;
  /* 核心：背景线性渐变（从左到右，浅蓝→浅紫→浅粉） */
  background: linear-gradient(to right, #a0c4ff, #bde0fe, #c8b6ff);
  /* 保留你原有所有布局属性，确保铺满网页 */
  min-height: 100vh;
  margin: 0 !important;
  width: 100% !important;
  box-sizing: border-box !important;
  position: relative;
}

.view-header h2 {
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid var(--border-color);
}

.empty-state {
  text-align: center;
  padding: 5rem 1rem;
  background-color: var(--card-bg-color);
  border-radius: 12px;
  border: 2px dashed var(--border-color);
}
.empty-state p { font-size: 1.5rem; font-weight: 600; margin: 0 0 1rem; }
.empty-state span { color: var(--text-color-light); }

.favorites-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
  gap: 2rem;
}

.favorite-card {
  background-color: var(--card-bg-color);
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.05);
  transition: transform 0.2s, box-shadow 0.2s;
}
.favorite-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1);
}

.card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; }
.card-title-group h3 { margin: 0 0 0.25rem; font-size: 1.25rem; }
.card-title-group a { font-size: 0.9rem; color: var(--text-color-light); text-decoration: none; }
.card-title-group a:hover { text-decoration: underline; }

.remove-btn {
  background: transparent; border: none; color: var(--text-color-light);
  width: 36px; height: 36px; border-radius: 50%;
  font-size: 1.5rem; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: background-color 0.2s, color 0.2s;
}
.remove-btn:hover { background-color: var(--danger-color-light); color: var(--danger-color); }

.card-chart {
  width: 100%;
  height: 350px; /* 在卡片内部，可以给图表一个固定高度以保持对齐 */
}
</style>