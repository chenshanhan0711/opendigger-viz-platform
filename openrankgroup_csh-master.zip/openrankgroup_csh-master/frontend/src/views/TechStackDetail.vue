<!-- src/views/TechStackDetail.vue -->
<template>
  <div class="tech-detail-container">
   

    <!-- 技术栈分布详情内容 -->
    <main class="detail-content">
      <h2 class="page-title">技术栈分布</h2>
      <div class="layout-row">
        <!-- 左侧分类列表（可点击切换） -->
        <div class="category-list">
          <div 
            class="category-item" 
            :class="{active: activeCategory === 'frontend'}"
            @click="switchCategory('frontend')"
          >
            前端
          </div>
          <div 
            class="category-item" 
            :class="{active: activeCategory === 'backend'}"
            @click="switchCategory('backend')"
          >
            后端
          </div>
          <div 
            class="category-item" 
            :class="{active: activeCategory === 'algorithm'}"
            @click="switchCategory('algorithm')"
          >
            算法&竞赛方向
          </div>
        </div>
        <!-- 右侧柱状图 -->
        <div class="chart-container">
          <div ref="barChartRef" class="echarts-bar"></div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import * as echarts from 'echarts'

const router = useRouter()
const barChartRef = ref(null)
const activeCategory = ref('frontend') // 默认选中前端
let barChart = null

// 不同分类对应的图表数据
const chartDataMap = {
  // 前端数据
  frontend: {
    xData: ['0.9', '0.3', '0.9', '0.12', '0.15', '0.18', '0.21', '0.24', '0.27', '0.30', '0.33'],
    yData: [100, 150, 200, 250, 300, 350, 400, 450, 500, 450, 200],
    color: '#2563eb' // 蓝色
  },
  // 后端数据
  backend: {
    xData: ['0.9', '0.3', '0.9', '0.12', '0.15', '0.18', '0.21', '0.24', '0.27', '0.30', '0.33'],
    yData: [80, 120, 180, 220, 280, 320, 380, 420, 480, 400, 180],
    color: '#10b981' // 绿色
  },
  // 算法数据
  algorithm: {
    xData: ['0.9', '0.3', '0.9', '0.12', '0.15', '0.18', '0.21', '0.24', '0.27', '0.30', '0.33'],
    yData: [120, 180, 250, 300, 350, 400, 450, 500, 550, 480, 220],
    color: '#f59e0b' // 橙色
  }
}

// 初始化柱状图
const initBarChart = () => {
  if (!barChartRef.value) return
  barChart = echarts.init(barChartRef.value)
  updateChart() // 初始化时渲染数据
  window.addEventListener('resize', () => barChart.resize())
}

// 更新图表数据（切换分类时调用）
const updateChart = () => {
  const data = chartDataMap[activeCategory.value]
  const option = {
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: data.xData,
      axisLabel: { rotate: 45, fontSize: 12 }
    },
    yAxis: { type: 'value' },
    series: [{
      type: 'bar',
      data: data.yData,
      itemStyle: { color: data.color }
    }]
  }
  barChart.setOption(option)
}

// 切换分类
const switchCategory = (category) => {
  activeCategory.value = category
}

// 监听分类变化，自动更新图表
watch(activeCategory, () => {
  updateChart()
})

onMounted(() => {
  initBarChart()
})
</script>

<style scoped>
/* 全局容器 */
.tech-detail-container {
  font-family: "微软雅黑", sans-serif;
  background: linear-gradient(to right, #a0c4ff, #bde0fe, #c8b6ff);
  min-height: 100vh;
  padding: 20px;
  box-sizing: border-box;
}

/* 头部导航 */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border-bottom: 1px solid #eee;
  margin-bottom: 30px;
  background: white;
  border-radius: 8px;
  padding: 15px 20px;
}

.logo-title {
  font-size: 18px;
  font-weight: bold;
  color: #1e293b;
}

.nav {
  display: flex;
  gap: 20px;
}

.nav-item {
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  transition: background 0.2s;
}

.nav-item:hover {
  background: #f0f8ff;
}

/* 详情页内容 */
.detail-content {
  background: white;
  border-radius: 8px;
  padding: 20px;
}

.page-title {
  text-align: center;
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
  color: #1e293b;
}

/* 布局：左侧分类+右侧图表 */
.layout-row {
  display: flex;
  gap: 20px;
}

/* 左侧分类列表 */
.category-list {
  width: 120px;
}

.category-item {
  padding: 12px 8px;
  text-align: center;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin-bottom: 10px;
  cursor: pointer;
  background: #f8fafc;
  transition: all 0.2s ease;
}

.category-item:hover {
  background: #f0f9ff;
}

/* 选中状态样式 */
.category-item.active {
  background: #2563eb;
  color: white;
  border-color: #2563eb;
}

/* 右侧图表容器 */
.chart-container {
  flex: 1;
  height: 400px;
}

.echarts-bar {
  width: 100%;
  height: 100%;
}
</style>