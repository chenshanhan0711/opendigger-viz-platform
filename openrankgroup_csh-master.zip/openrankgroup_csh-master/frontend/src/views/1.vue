<template>
  <div class="layout-container">


    <!-- 内容区域：两个并列模块 -->
    <main class="content">
         <div class="module-group">
        <div class="module"></div> <!-- 空框 -->
        <div class="module-text">技术栈分布</div> <!-- 下方文字 -->
      </div>
     <div class="module-group">
        <div class="module"></div> <!-- 空框 -->
        <div class="module-text">热门项目活跃度趋势</div> <!-- 下方文字 -->
      </div>
    </main>
  </div>
</template>

<script setup>
// 导航按钮点击事件（可根据业务需求扩展，如路由跳转）
const handleNavClick = (navType) => {
  console.log(`点击了${navType}按钮`);
  // 示例：若需要路由跳转，可导入useRouter
  // import { useRouter } from 'vue-router';
  // const router = useRouter();
  // switch(navType) {
  //   case 'overview': router.push('/overview'); break;
  //   // 其他导航项路由配置
  // }
};
</script>

<style scoped>
/* 全局容器样式 */
.layout-container {
  padding: 20px;
  font-family: "微软雅黑", sans-serif;
}

/* 头部样式：Flex布局实现左右对齐 */
.header {
  display: flex;
  justify-content: space-between; /* 左右两端对齐 */
  align-items: center; /* 垂直居中 */
  padding: 10px;
  border-bottom: 1px solid #eee;
  margin-bottom: 60px;
}

.logo-title {
  padding: 8px 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
}

/* 导航样式 */
.nav {
  display: flex;
  gap: 30px; /* 导航项之间的间距，无需手动设置margin */
}

.nav-item {
  padding: 6px 12px; 
  border-radius: 4px;
  cursor: pointer;
  color: #333;
  transition: background-color 0.2s; /* 点击过渡效果，提升体验 */
}

.nav-item:hover {
  background-color: #f0c800; /*  hover 深色效果 */
}

/* 内容区域：Flex布局实现模块并列 */
.content {
  display: flex;
  gap: 40px; /* 两个模块之间的间距 */
  flex-wrap: wrap; /* 小屏幕自动换行，响应式适配 */
}
/* 新增：模块组样式 - 实现文字在框下方整体居中 */
.module-group {
  display: flex;
  flex-direction: column; /* 垂直排列（框在上，文字在下） */
  align-items: center; /* 水平居中：让框和文字都居中对齐 */
  gap: 30px; /* 框和文字之间的间距，可根据需要调整 */
}

/* 模块样式 */
.module {
  width: 700px;
  height: 400px;
  border: 3px solid #ccc;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end; /* 文字靠下对齐 */
  padding: 10px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05); /* 轻微阴影，提升层次感 */
}

.module-text {
  padding: 4px 8px;
  border-radius: 4px;
  color: #333;
  font-weight: 500;
   /* 1. 文字放大：调整font-size数值即可，数值越大文字越大 */
  font-size: 28px; /* 原默认无此属性，新增：28px视觉效果醒目，可改32px/24px */
  /* 2. 文字自身水平居中：必加属性 */
  text-align: center;
  /* 可选：加粗文字，放大后更醒目（保留你的font-weight，可升级为700更粗） */
  font-weight: 700;
}
</style>
