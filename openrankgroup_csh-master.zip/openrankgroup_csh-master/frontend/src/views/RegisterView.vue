<template>
  <div class="register-container">
    <div class="register-card">
      <h2>用户注册</h2>
      <!-- 错误提示 -->
      <div v-if="authStore.error" class="error-tip">{{ authStore.error }}</div>
      
      <!-- 注册表单 -->
      <form @submit.prevent="handleRegister">
        <div class="form-group">
          <label>用户名</label>
          <input
            type="text"
            v-model="registerForm.username"
            required
            placeholder="请输入3-20位用户名"
          >
        </div>
        <div class="form-group">
          <label>邮箱</label>
          <input
            type="email"
            v-model="registerForm.email"
            required
            placeholder="请输入正确格式的邮箱"
          >
        </div>
        <div class="form-group">
          <label>密码</label>
          <input
            type="password"
            v-model="registerForm.password"
            required
            placeholder="请输入6-20位密码"
          >
        </div>
        <button type="submit" :disabled="authStore.loading" class="register-btn">
          {{ authStore.loading ? '注册中...' : '注册' }}
        </button>
      </form>
      
      <!-- 跳转登录 -->
      <div class="login-link">
        已有账号？<router-link to="/login">立即登录</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useAuthStore } from '@/stores/auth';
import { useRouter } from 'vue-router';

const authStore = useAuthStore();
const router = useRouter();

// 注册表单数据
const registerForm = ref({
  username: '',
  email: '',
  password: ''
});

// 注册处理
const handleRegister = async () => {
  try {
    const success = await authStore.register(registerForm.value);
    if (success) {
      // 注册成功后跳转到登录页
      router.push('/login');
    }
  } catch (err) {
    // 错误已在authStore中处理，无需额外操作
  }
};
</script>

<style scoped>
/* 与登录页面样式复用，仅调整部分文本 */
.register-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: calc(100vh - 70px);
  background: linear-gradient(to right, #a0c4ff, #bde0fe, #c8b6ff);
  padding: 20px;
}

.register-card {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  width: 100%;
  max-width: 400px;
}

.register-card h2 {
  text-align: center;
  margin-bottom: 1.5rem;
  color: #1e293b;
}

.error-tip {
  color: #ef4444;
  text-align: center;
  margin-bottom: 1rem;
}

.form-group {
  margin-bottom: 1rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: #475569;
  font-weight: 500;
}

.form-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #e2e8f0;
  border-radius: 4px;
  font-size: 1rem;
}

.register-btn {
  width: 100%;
  padding: 0.75rem;
  background: #2563eb;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.register-btn:disabled {
  background: #94a3b8;
  cursor: not-allowed;
}

.login-link {
  text-align: center;
  margin-top: 1rem;
  color: #64748b;
}

.login-link a {
  color: #2563eb;
  text-decoration: none;
}

.login-link a:hover {
  text-decoration: underline;
}
</style>