// 1. 统一导入核心依赖（补全缺失的 useAuthStore 导入）
import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '@/stores/auth'; // 关键：补全缺失的导入

// 2. 统一导入所有组件（路径规范为 @/views/，避免混用）
import HomeView from '@/views/HomeView.vue';
import FavoritesView from '@/views/FavoritesView.vue';
import researchView from '@/views/researchView.vue';
import startView from '@/views/startView.vue';
import TechStackDetail from '@/views/TechStackDetail.vue'; // 统一路径
import LoginView from '@/views/LoginView.vue';
import RegisterView from '@/views/RegisterView.vue';

// 3. 路由规则（保持不变，仅格式优化）
const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
  },
  {
    path: '/research',
    name: 'research',
    component: researchView,
  },
  {
    path: '/Favorites',
    name: 'Favorites',
    component: FavoritesView,
    meta: { requiresAuth: true } // 收藏页需登录
  },
  {
    path: '/start',
    name: 'start',
    component: startView,
  },
  { 
    path: '/tech-stack-detail', 
    name: 'TechStackDetail', 
    component: TechStackDetail
  },
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
  {
    path: '/register',
    name: 'register',
    component: RegisterView
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/'
  }
];

// 4. 只创建一次路由实例（合并 scrollBehavior 配置）
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
  scrollBehavior() { // 滚动行为配置合并到这里
    return { top: 0 };
  }
});

// 5. 路由守卫（逻辑不变，依赖已补全）
router.beforeEach(async (to, from, next) => {
  const authStore = useAuthStore();
  
  if (!authStore.token) {
    authStore.loadFromStorage();
  }

  if (to.meta.requiresAuth) {
    if (authStore.token) {
      const isValid = await authStore.validateToken();
      if (isValid) {
        next();
      } else {
        next({ name: 'login', query: { redirect: to.fullPath } });
      }
    } else {
      next({ name: 'login', query: { redirect: to.fullPath } });
    }
    return;
  }

  next();
});

export default router;