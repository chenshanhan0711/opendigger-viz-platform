import { defineStore } from 'pinia';
import { authApi } from '@/api/api';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: null,        // JWT Token
    user: null,         // 当前用户信息
    loading: false,     // 登录/注册加载状态
    error: null         // 错误信息
  }),
  actions: {
    /**
     * 从本地存储加载登录状态（页面刷新后恢复）
     */
    loadFromStorage() {
      const token = localStorage.getItem('access_token');
      const userStr = localStorage.getItem('auth_user');
      if (token && userStr) {
        this.token = token;
        this.user = JSON.parse(userStr);
      }
    },

    /**
     * 用户注册
     * @param {Object} userInfo - { username, email, password }
     * @returns 注册是否成功
     */
    async register(userInfo) {
      this.loading = true;
      this.error = null;
      try {
        const res = await authApi.register(userInfo);
        // 注册成功后无需自动登录，提示用户手动登录
        alert(res.message || '注册成功，请登录');
        return true;
      } catch (err) {
        this.error = err.response?.data?.detail || '注册失败';
        throw err;
      } finally {
        this.loading = false;
      }
    },

    /**
     * 用户登录
     * @param {Object} loginInfo - { username: '用户名/邮箱', password }
     * @returns 登录是否成功
     */
    async login(loginInfo) {
      this.loading = true;
      this.error = null;
      try {
        const res = await authApi.login(loginInfo);
        const { access_token, user } = res;
        // 更新状态并本地持久化（刷新页面不丢失）
        this.token = access_token;
        this.user = user;
        localStorage.setItem('access_token', access_token);
        localStorage.setItem('auth_user', JSON.stringify(user));
        return true;
      } catch (err) {
        this.error = err.response?.data?.detail || '登录失败';
        throw err;
      } finally {
        this.loading = false;
      }
    },

    /**
     * 用户退出登录
     */
    logout() {
      authApi.logout();  // 调用api中的清除方法
      this.token = null;
      this.user = null;
    },

    /**
     * 验证Token有效性（路由守卫/页面刷新时调用）
     * @returns Token是否有效
     */
    async validateToken() {
      if (!this.token) return false;
      try {
        await authApi.getCurrentUser();  // 调用后端/me接口验证
        return true;
      } catch (err) {
        this.logout();  // Token无效则退出登录
        return false;
      }
    }
  }
});