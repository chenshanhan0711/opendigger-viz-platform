import { defineStore } from 'pinia';
import { favoritesApi } from '@/api/api';

const KIND_SINGLE = 'single';
const KIND_PLAN = 'plan';

export const useFavoritesStore = defineStore('favorites', {
  state: () => ({
    favorites: [],
    loading: false,
    error: null
  }),
  actions: {
    // 加载当前用户的收藏列表
    async fetchFavorites() {
      this.loading = true;
      try {
        const res = await favoritesApi.list();
        this.favorites = res.favorites || [];
      } catch (err) {
        this.error = err.response?.data?.detail || '加载收藏失败';
        throw err;
      } finally {
        this.loading = false;
      }
    },
    // 标准化single类型收藏的输入参数
    normalizeSingleInput(arg1, arg2) {
      if (arg1 && typeof arg1 === 'object') {
        // 传入对象：{ full_name, metric, platform, ... }
        return {
          full_name: (arg1.full_name ?? arg1.fullName ?? arg1.repo ?? '').trim(),
          metric: (arg1.metric ?? '').trim(),
          platform: (arg1.platform ?? 'github').trim(),
          title: arg1.title ?? '',
          url: arg1.url ?? ''
        };
      }
      // 传入两个字符串：(full_name, metric)
      return {
        full_name: (arg1 ?? '').toString().trim(),
        metric: (arg2 ?? '').toString().trim(),
        platform: 'github',
        title: '',
        url: ''
      };
    },
    // 查找single类型收藏是否已存在
    findSingle(full_name, metric, platform = 'github') {
      const uniq_key = `single:${platform}:${full_name}:${metric}`;
      return this.favorites.find(
        item => item.kind === KIND_SINGLE && item.uniq_key === uniq_key
      );
    },
    // 新增single类型收藏
    async addSingle(arg1, arg2) {
      const { full_name, metric, platform, title, url } = this.normalizeSingleInput(arg1, arg2);
      if (!full_name || !metric) {
        alert('收藏需要项目名称和指标');
        return false;
      }

      const body = {
        kind: KIND_SINGLE,
        uniq_key: `single:${platform}:${full_name}:${metric}`,
        full_name,
        metric,
        platform,
        title,
        url
      };

      try {
        const res = await favoritesApi.add(body);
        this.favorites.unshift(res.favorite); // 新增收藏插入到列表头部
        return true;
      } catch (e) {
        alert(e.response?.data?.detail || '收藏失败');
        return false;
      }
    },
    // 删除收藏
    async removeFavorite(id) {
      try {
        await favoritesApi.remove(id);
        this.favorites = this.favorites.filter(item => item.id !== id);
        return true;
      } catch (e) {
        alert(e.response?.data?.detail || '删除失败');
        return false;
      }
    },
    // 切换收藏状态（已收藏则删除，未收藏则新增）
    async toggleSingle(arg1, arg2) {
      const { full_name, metric, platform } = this.normalizeSingleInput(arg1, arg2);
      const existed = this.findSingle(full_name, metric, platform);
      if (existed) {
        return await this.removeFavorite(existed.id);
      }
      return await this.addSingle(arg1, arg2);
    },
    // 新增plan类型收藏（方案/榜单）
    async addPlan({ uniq_key, title, payload }) {
      if (!uniq_key) {
        alert('榜单收藏需要唯一标识');
        return false;
      }
      try {
        const res = await favoritesApi.add({
          kind: KIND_PLAN,
          uniq_key,
          title,
          payload
        });
        this.favorites.unshift(res.favorite);
        return true;
      } catch (e) {
        alert(e.response?.data?.detail || '榜单收藏失败');
        return false;
      }
    },
    // 清空收藏列表（本地状态，未调用接口）
    clear() {
      this.favorites = [];
    }
  },
  // 别名兼容（旧组件调用兼容）
  getters: {
    addFavorite: (state) => state.addSingle,
    toggleFavorite: (state) => state.toggleSingle
  }
});